package com.example.checkboxes_and_etc;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    CheckBox chocolate_syrup, sprinkles, crushed_nuts, cherries, orio_cookie_crumbles;
    Button button_show;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addListenerOnButtonClick();
    }

    private void addListenerOnButtonClick() {
        chocolate_syrup = findViewById(R.id.checkBox1);
        sprinkles = findViewById(R.id.checkBox2);
        crushed_nuts = findViewById(R.id.checkBox3);
        cherries = findViewById(R.id.checkBox4);
        orio_cookie_crumbles = findViewById(R.id.checkBox5);
        button_show = findViewById(R.id.btn_showToast);

        button_show.setOnClickListener(view -> {
            StringBuilder result = new StringBuilder();
            result.append("Toppings:");

            if(chocolate_syrup.isChecked()){
                result.append(" Chocolate syrup");
            }
            if(sprinkles.isChecked()){
                result.append(" Sprinkles");
            }
            if(crushed_nuts.isChecked()){
                result.append(" Crushed nuts");
            }
            if(cherries.isChecked()){
                result.append(" Cherries");
            }
            if(orio_cookie_crumbles.isChecked()){
                result.append(" Orio cookie crumbles");
            }

            Toast.makeText(getApplicationContext(), result.toString(), Toast.LENGTH_LONG).show();
        });
    }
}